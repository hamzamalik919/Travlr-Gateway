import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { AuthResponse } from '../models/user';
import { BROWSER_STORAGE } from '../storage';
import { Http } from '@angular/http';
import { promise } from 'protractor';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  constructor(private http: Http,

    @Inject(BROWSER_STORAGE) private storage: Storage) { }
  private apiBaseUrl = "http://localhost:3000/api/";
  private triUrl = `${this.apiBaseUrl}trips/`;
  private handleError(error: any): promise<any> {
    console.error('Something has gone wrong', error);
    return Promise.reject(error.message || error);
  }
  public login(user: User): Promise<AuthResponse> {
    return this.makeAuthApiCall('login', user);
  }
  public register(user: User): Promise<AuthResponse> {
    return this.makeAuthApiCall('register', user);
  }
  private makeAuthApiCall(urlPath: string, user: User):
    Promise<AuthResponse> {
    const url: string = `${this.apiBaseUrl}/${urlPath}`;
    return this.http
      .post(url, user)
      .toPromise()
      .then(response => response.json() as AuthResponse)
      .catch(this.handleError);
  }
}

