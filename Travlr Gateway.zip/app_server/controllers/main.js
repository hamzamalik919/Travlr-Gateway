const index = (req, res)=>{
    res.render('index', {title: "Travel Gateways"});
};

module.exports = {
    index
};